
package main_empleados_y_empresa;


public class empleados {
    String nombres;
    String apellidos;
    int edad;
    double numerotel;
    String genero;
public empleados(String nm, String Ap, int ed, double nt,String ge){
    this.nombres=nm;
    this.apellidos=Ap;
    this.edad=ed;
    this.numerotel=nt;
    this.genero=ge;

}
public empleados (){
}

  public String getnombres(){
  return nombres;
  }
  public void setnombres (String Nm){
  nombres=Nm;
  }
  public String getapellidos(){
  return apellidos;
  }
  public void setapellidos(String ap){
  apellidos=ap;
  }
  public int getedad(){
  return edad;
  }
   public void setedad(int eda){
  edad=eda;
  }
    public double getnumerotel(){
  return numerotel;
  }
  public void setnumerotel(double tel){
  numerotel=tel;
  }
  public String getgenero(){
  return genero;
  }
   public void setgenero(String gen){
    genero=gen;
  }
}
