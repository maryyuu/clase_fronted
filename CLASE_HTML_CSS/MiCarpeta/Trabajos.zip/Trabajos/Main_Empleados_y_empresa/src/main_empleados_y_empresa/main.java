
package main_empleados_y_empresa;

import java.util.Scanner;


public class main {
    public static void main(String[] args) {
        Scanner tec= new Scanner(System.in);
         Scanner ec=new Scanner (System.in);
          Scanner dec=new Scanner (System.in);
        empleados arry[]= new empleados[3];
        System.out.println("EMPLEADOS");
        System.out.println("Digite datos");
        for(int i=0;i<arry.length;i++){
            System.out.println("Digite su nombre:");
            String a= tec.nextLine();
            System.out.println("Digite su apellido:");
            String b=tec.nextLine();
            System.out.println("Digite su edad:");
            int c=ec.nextInt();
            System.out.println("Digite N° de telefono:");
            double d=dec.nextDouble();
            System.out.println("Ingrese su genero:");
            String e=tec.nextLine();
            tec.nextLine();
            empleados objeto=new empleados();
            objeto.setnombres(a);
            objeto.setapellidos(b);
            objeto.setedad(c);
            objeto.setnumerotel(d);
            objeto.setgenero(e);
            arry[i]=objeto;

        }   System.out.println("LLENO DE ARREGLOS (empleados)");
        for(int j=0;j<arry.length;j++){
              System.out.println("Datos:"+ arry[j].getnombres()+arry[j].getapellidos()+arry[j].getedad()+arry[j].getnumerotel()+arry[j].getgenero()); 
        }
        System.out.println("POSICION DE ARREGLO (empleados)");
        for(int p=0;p<arry.length;p++){
         if (arry[p].getedad()==1){
             System.out.println("posicion: "+p);
             System.out.println("1."+ arry[p].getnombres());   
         }
        }
            System.out.println("CRITERIO ELIMINADO (empleados)");
        for(int q=0;q<arry.length;q++){
        if(arry[q].getnumerotel()==2){
            System.out.println("posicion:"+q);
            arry[q]=null;
        }
        }
        System.out.println("EMPRESA");
        empresa arry2[]= new empresa[3];
        System.out.println("Digite datos");
        for(int w=0;w<arry.length;w++){
            System.out.println("Digite nombre de la empresa:");
            String f= tec.nextLine();
            System.out.println("Digite ubicacion:");
            String g=tec.nextLine();
            System.out.println("Digite N° empleados:");
            int h=ec.nextInt();
            System.out.println("Digite profesion:");
            String r=tec.nextLine();
            System.out.println("Ingrese N° de telefono:");
            Double y=dec.nextDouble();
            tec.nextLine();
            empresa objeto2=new empresa();
            objeto2.setnombre(f);
            objeto2.setubicacion(g);
            objeto2.setnumero_de_empleados(h);
            objeto2.setprofesion(r);
            objeto2.setelefono(y);
            arry2[w]=objeto2;

        }   System.out.println("LLENO DE ARREGLOS (empresa)");
        for(int z=0;z<arry.length;z++){
              System.out.println("Datos:"+ arry2[z].getnombre()+arry2[z].getubicacion()+arry2[z].getnumero_de_empleados()+arry2[z].getprofesion()+arry2[z].gettelefono()); 
        }
        System.out.println("POSICION DE ARREGLO (empresa)");
        for(int x=0;x<arry2.length;x++){
         if (arry2[x].gettelefono()==1){
             System.out.println("posicion: "+x);
             System.out.println("1."+ arry2[x].getnombre());   
         }
        }
            System.out.println("CRITERIO ELIMINADO (empresa)");
        for(int v=0;v<arry.length;v++){
        if(arry2[v].getnumero_de_empleados()==2){
            System.out.println("posicion:"+v);
            arry2[v]=null;
        }
        }

    
    
    
    }
    
}
