
package main_empleados_y_empresa;


public class empresa {
     String nombre;
    String ubicacion;
    int numero_de_empleados;
    String profesion;
    double telefono;
    
public empresa(String nm2, String ubi, int nde2, String pr,double tel2){
    this.nombre=nm2;
    this.ubicacion=ubi;
    this.numero_de_empleados=nde2;
    this.profesion=pr;
    this.telefono=tel2;

}
public empresa (){
}
public String getnombre(){
  return nombre;
  }
  public void setnombre (String Nm3){
  nombre=Nm3;
  }
  public String getubicacion(){
  return ubicacion;
  }
  public void setubicacion(String ubi1){
  ubicacion=ubi1;
  }
  public int getnumero_de_empleados(){
  return numero_de_empleados;
  }
   public void setnumero_de_empleados(int nm2){
  numero_de_empleados=nm2;
  }
    public String getprofesion(){
  return profesion;
  }
  public void setprofesion(String pro){
  profesion=pro;
  }
  public double gettelefono(){
  return telefono;
  }
   public void setelefono(double te){
    telefono=te;
  }


}
