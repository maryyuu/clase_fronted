/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author SENA
 */
public class Main {
    
   public static void main(String[] args) {
       //DEPORTISTAS
       Deportista a=new Deportista();
       a.setnombre("Radamel");
       a.setapellido("Falcao");
       a.settelefono ("12334974");
       a.setdireccion("Norte");
       a.setvelocidad(123);
       System.out.println(a.getnombre()+a.getapellido()+a.getdireccion()+a.gettelefono());
       System.out.println(a.velocidaddoble());
       //PROGRAMADORES
       Programadores b=new Programadores();
       b.setnombre("Maryuri");
       b.setapellido("Lopez");
       b.setdireccion("Norte");
       b.settelefono("m7947");
       b.setlenguaje("Java");
       System.out.println(b.getnombre()+b.getapellido()+b.getdireccion()+b.gettelefono());
       System.out.println(b.datos());
    }
    
}
