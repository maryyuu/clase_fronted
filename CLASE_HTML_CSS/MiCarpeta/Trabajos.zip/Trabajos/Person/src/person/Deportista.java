/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author SENA
 */
public class Deportista extends Person{
    int velocidad;
    private int velocidaddoble;
    public int getvelocidad(){
    return velocidad;
    }
    public void setvelocidad(int vel){
    this.velocidad=vel;
    }
    public void velocidaddoble(int vel){
        this.velocidaddoble=vel;
    }
    public String velocidaddoble(){
    int velocidaddoble=this.velocidad*2;
    return getnombre()+getapellido()+velocidaddoble;
    }

}
