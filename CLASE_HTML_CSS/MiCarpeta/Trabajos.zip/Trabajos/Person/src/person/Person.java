
package person;


public class Person {
protected String nombre;
protected String apellido;
protected String direccion;
protected String telefono;
public String getnombre(){
return nombre;
}
public void setnombre(String nm){
this.nombre=nm;
}
public String getapellido(){
return apellido;
}
public void setapellido(String ap){
this.apellido=ap;
}
public String getdireccion(){
return direccion;
}
public void setdireccion(String dir){
this.direccion=dir;
}
public String gettelefono(){
return telefono;
}
public void settelefono(String tel){
this.telefono=tel;
}

    
}
