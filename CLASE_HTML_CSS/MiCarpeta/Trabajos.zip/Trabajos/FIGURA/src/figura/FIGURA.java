
package figura;

public class FIGURA {
//EJERCICIO #1
    //MARYURI CHARIGD LOPEZ
    protected float area;
    protected float perimetro;
    

    public FIGURA(float area, float perimetro) {
        this.area = area;
        this.perimetro = perimetro;
    }

    public float getarea() {
        return area;
    }

    public void setarea(float area) {
        this.area = area;
    }

    public float getperimetro() {
        return perimetro;
    }

    public void setperimetro(float perimetro) {
        this.perimetro = perimetro;
    }
    
    
    
}
