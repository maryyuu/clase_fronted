/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figura;

/**
 *
 * @author SENA
 */
public class Rectangulo extends FIGURA {
    float ladolargoa;
   float ladoanchoa;
   float ladolargo1;
    float ladolargo2;
    float ladoancho1;
    float ladoancho2;
float areaT;

    public Rectangulo(float ladolargoa, float ladoanchoa, float ladolargo1, float ladolargo2, float ladoancho1, float ladoancho2, float areaT, float area, float perimetro) {
        super(area, perimetro);
        this.ladolargoa = ladolargoa;
        this.ladoanchoa = ladoanchoa;
        this.ladolargo1 = ladolargo1;
        this.ladolargo2 = ladolargo2;
        this.ladoancho1 = ladoancho1;
        this.ladoancho2 = ladoancho2;
        this.areaT = areaT;
    }

    public float getareaT() {
        return areaT;
    }

    public void setareaT(float areaT) {
        this.areaT = areaT;
    }
    

    public float getladolargoa() {
        return ladolargoa;
    }

    public void setladolargoa(float ladolargoa) {
        this.ladolargoa = ladolargoa;
    }

    public float getladoanchoa() {
        return ladoanchoa;
    }

    public void setladoanchoa(float ladoanchoa) {
        this.ladoanchoa = ladoanchoa;
    }

    public float getladolargo1() {
        return ladolargo1;
    }

    public void setladolargo1(float ladolargo1) {
        this.ladolargo1 = ladolargo1;
    }

    public float getLadolargo2() {
        return ladolargo2;
    }

    public void setLadolargo2(float ladolargo2) {
        this.ladolargo2 = ladolargo2;
    }

    public float getLadoancho1() {
        return ladoancho1;
    }

    public void setLadoancho1(float ladoancho1) {
        this.ladoancho1 = ladoancho1;
    }

    public float getLadoancho2() {
        return ladoancho2;
    }

    public void setLadoancho2(float ladoancho2) {
        this.ladoancho2 = ladoancho2;
    }
   public float areaT(){
   int areaT=this.ladolargoa*ladoanchoa;
    return getarea()+getperimetro()+areaT;
    }
   

   

}
