
package figura;


public class Circulo extends FIGURA {
 
    float pi;
    float radio;

    public Circulo(float pi, float radio, float area, float perimetro) {
        super(area, perimetro);
        this.pi = pi;
        this.radio = radio;
    }

    public float getpi() {
        return pi;
    }

    public void setpi(float pi) {
        this.pi = pi;
    }

    public float getradio() {
        return radio;
    }

    public void setradio(float radio) {
        this.radio = radio;
    }
    

 
    
}
