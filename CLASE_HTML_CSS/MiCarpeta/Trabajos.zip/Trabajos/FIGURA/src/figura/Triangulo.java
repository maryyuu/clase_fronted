/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figura;

/**
 *
 * @author SENA
 */
public class Triangulo extends FIGURA {
    float base;
    float altura;
    float lado1;
    float lado2;
    float lado3;

    public Triangulo(float base, float altura, float lado1, float lado2, float lado3, float area, float perimetro) {
        super(area, perimetro);
        this.base = base;
        this.altura = altura;
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    public float getbase() {
        return base;
    }

    public void setbase(float base) {
        this.base = base;
    }

    public float getaltura() {
        return altura;
    }

    public void setaltura(float altura) {
        this.altura = altura;
    }

    public float getlado1() {
        return lado1;
    }

    public void setlado1(float lado1) {
        this.lado1 = lado1;
    }

    public float getlado2() {
        return lado2;
    }

    public void setLado2(float lado2) {
        this.lado2 = lado2;
    }

    public float getLado3() {
        return lado3;
    }

    public void setLado3(float lado3) {
        this.lado3 = lado3;
    }

    
    
}
