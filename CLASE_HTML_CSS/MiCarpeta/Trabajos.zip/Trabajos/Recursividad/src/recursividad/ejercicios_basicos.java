
package recursividad;
import java.util.Scanner;
public class ejercicios_basicos {
    public static void main (String [ ] args) {
        Scanner tec=new Scanner (System.in);
      double sala;
    //Horas
        System.out.println("____________________________________________________");
        System.out.println("HORAS TRABAJADAS");
        System.out.println("Ingrese horas trabajadas");
        int a=tec.nextInt();
        System.out.println("Ingrese Valor por hora");
        float b=tec.nextInt();
        
        sala=b*a;
        
        System.out.println("Su salario es de:"+ sala);
        System.out.println("_________________________________________________________");
        //50 numeros
       // int vc1 []=new int[50];
       int rand=0;
        System.out.println("INGRESE NUMEROS N(50)");
        System.out.println("Cantidad maxima de numeros es 50");
        System.out.println("Ingrese cantidad de numeros a imprimir:");
        int c=tec.nextInt();
        System.out.println("Numeros:");
        for(int i=1;i<=c;i++){
          rand=(int)(Math.random()*100+1);
             System.out.println(rand);
        
             if(rand%2==0){
                 System.out.println("Es par:"+rand);
             }else{
                 System.out.println("es impar:"+rand);
             }
             if(rand>0){
                 System.out.println("Es positivo:"+rand);
             }else{
                 System.out.println("Es negativo:"+rand);
             }
    }System.out.println("_____________________________________________________");
    //Numeros de 20
        System.out.println("Numeros comprendidos entre 20");
        System.out.println("Ingrese numero:");
        int d=tec.nextInt();
        if(d>20){
            int acu=0;
            System.out.println("Numeros comprendidos:");
        for(int i=20;i<=d;i++){
            System.out.println(i);
            if(i%2==0){
            acu=acu+i;
                
            }
        }
          System.out.println("La suma de los numeros pares es de:"+acu);
        }
        System.out.println("____________________________________________");
    
    //REPETITIVO
        System.out.println("Ingrese un numero(REPETITIVO):");
    int h=tec.nextInt();
    int cont=0;
    for(int q=0;q<=h;q++){
    cont=cont+q;
        
    }
    System.out.println("Suma de numeros"+cont);
    //Numeros por teclado
        System.out.println("_________________________________");
        System.out.println("NUMEROS POR TECLADO(mayor,igual)");
        System.out.println("Ingrese primer numero:");
        int f =tec.nextInt();
        System.out.println("Ingrese segundo numero");
        int g=tec.nextInt();
            if(g==f){
        System.out.println("Son iguales");
            }
         if(f>g){
            System.out.println("Es mayor:"+f);
        }
         if(g>f){
            System.out.println("Es mayor:"+g);
        }
     
       
         
    }
    
}
        
   




