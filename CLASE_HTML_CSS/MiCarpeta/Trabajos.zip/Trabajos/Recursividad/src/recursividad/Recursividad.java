
package recursividad;
public class Recursividad {

    public static void main(String[] args) {
        
        Recursividad n=new Recursividad();
        //n.imprimir(5);
     
       
    }
   public void imprimir(int a){
        if(a>0){
        a=a-1;
        imprimir (a);
        System.out.println(a);
        }
    
    }
    }

