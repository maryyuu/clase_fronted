
package recursividad;

import java.util.Scanner;

public class suma_recursiva {
    
 public static void main(String[] args) {
          Scanner tec= new Scanner  (System.in);
   int count=0;//Realizar suma
   int q=0;//int respuesta;//Numero de numeros que estoy sumando
    System.out.println("Ingrese valor:");
     int a=tec.nextInt();
         suma_recursiva n=new  suma_recursiva();
      
       n.suma(q,count,tec);
       System.out.println(n.suma(q,count,tec));

 }  
 public int  suma(int q, int count,Scanner tec){
       int a=tec.nextInt();
       while(q<2){
           q=a;
           q++;
       count=count+a;
        suma(q,count,tec);
       }

        return count;
}
}