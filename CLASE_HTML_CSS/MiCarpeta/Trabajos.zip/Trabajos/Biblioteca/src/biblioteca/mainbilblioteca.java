
package biblioteca;

import java.util.Scanner;

/**
 *
 * @author SENA
 */
public class mainbilblioteca {
    public static void main (String[] args){
    /* int [] numeros={1,2,3,4,5};
     Biblioteca bil[]={new Biblioteca(1,"Lioteca",2)]; 
        new Biblioteca(2,"cien años de soledad",7);
         new Biblioteca(3,"Romeo y julieta",6);
        
         String rta =bil[0].toString();
         System.out.println(rta);
         String rta2=bil[1].toString();
         System.out.println(rta2);
         String rta3=bil[2].toString();
         System.out.println(rta3);
        
    int [] numero= new int [a.length()];
   
    Biblioteca arrayBiblioteca[]=new Biblioteca[5];
   arrayBiblioteca[0]=new Biblioteca(1,"La llorona",7);
    arrayBiblioteca[1]=new Biblioteca(2,"La llorona1",9);
    arrayBiblioteca[2]=new Biblioteca(3,"La llorona2",45);
    arrayBiblioteca[3]=new Biblioteca(4,"La llorona3",8);
    arrayBiblioteca[4]=new Biblioteca(5,"La llorona4",0);
    for(int i=0;i<numero.length;i++){
        
        System.out.println(arrayBiblioteca[i].getcod()+arrayBiblioteca[i].getLibro()+arrayBiblioteca[i].getnumeroPag());
    }*/
 Scanner ec=new Scanner (System.in);
  Scanner tec=new Scanner (System.in);
 Biblioteca arry[]=new Biblioteca[3];
        System.out.println("Digite los datos:");
 for(int i=0;i<arry.length;i++){
     System.out.println("Digite codigo");  
       int a=ec.nextInt();
       System.out.println("Digite libro:");
       String b= tec.nextLine();
       System.out.println("Digite paginas:");
       int c= ec.nextInt();
       tec.nextLine();
       Biblioteca objeto = new Biblioteca();
       objeto.setcod(a);
       objeto.setLibro(b);
       objeto.setnumeroPag(c);
       arry[i]=objeto;
 }
 for(int j=0;j<arry.length;j++){
 if(arry[j].getcod()==1){
     System.out.println("Nombre del codi"+arry[j].getcod());
 }
 }

    }
}
