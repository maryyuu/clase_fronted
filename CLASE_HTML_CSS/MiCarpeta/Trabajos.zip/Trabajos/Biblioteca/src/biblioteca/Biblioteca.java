
package biblioteca;


public class Biblioteca {
    int cod;
    String Libro;
    int numeroPag;
   
   
    public Biblioteca (int cod, String Libro, int numeroPag) {
   this.cod=cod;
   this.Libro=Libro;
   this.numeroPag= numeroPag;
  
    }
     public Biblioteca(){
   }
    @Override
    public String toString(){
    return ("su codigo es:"+ cod +"El nombre del libro es:"+Libro+"Numero de paginas:"+numeroPag);
    }
  public int getcod(){
  return cod;
  }
  public void setcod (int Co){
  cod=Co;
  }
  public String getLibro(){
  return Libro;
  }
  public void setLibro(String li){
  Libro=li;
  }
  public int getnumeroPag(){
  return numeroPag;
  }
   public void setnumeroPag(int nm){
  numeroPag=nm;
  }
  
  
}
