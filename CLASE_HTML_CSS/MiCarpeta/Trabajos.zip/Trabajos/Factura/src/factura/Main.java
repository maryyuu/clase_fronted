
package factura;

public class Main {
     public static void main(String[] args) {
          Precio c=new Precio();
          c.setnombreempresa("ADIDAS");
          c.setnombrecliente("Maryuri");
          c.setproductos("Zapatos");
          c.setcantidad("200");
          c.setvalor(4500);
         System.out.println(c.getnombreempresa()+"-"+c.getnombrecliente()+"-"+c.getproductos()+"-"+c.getcantidad()+"-"+c.getvalor());
     
       System.out.println(c.precio());
 
    }  
}
