
package factura;

public class Precio extends Factura {
    
    double valor;
    public double getvalor(){
   return valor;
   }
     public void setvalor(double val){
   this.valor=val;
   }
   public String precio(){
   return getnombreempresa()+"-"+getnombrecliente()+"-"+getproductos()+"-"+getcantidad()+"-"+this.valor;
   }
    
}
