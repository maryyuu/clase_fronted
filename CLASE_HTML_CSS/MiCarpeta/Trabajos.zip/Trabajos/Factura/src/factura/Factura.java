
package factura;


public class Factura {

 protected String nombreempresa;
 protected String nombrecliente;
 protected String productos;
 protected String cantidad;
 
 public String getnombreempresa(){
return nombreempresa;
}
public void setnombreempresa(String nme){
this.nombreempresa=nme;
}
public String getnombrecliente(){
return nombrecliente;
}
public void setnombrecliente(String nmc){
this.nombrecliente=nmc;
}
public String getproductos(){
return productos;
}
public void setproductos(String pro){
this.productos=pro;
}
public String getcantidad(){
return cantidad;
}
public void setcantidad(String can){
this.cantidad=can;
}
}
